import { useState } from "react";
import AvatarScene from "@/components/AvatarScene";
import ChatInterface from "@/components/ChatInterface";
import SystemOverlay from "@/components/SystemOverlay";
import CameraPreview from "@/components/CameraPreview";
import { Loader2 } from "lucide-react";
import { useChatHistory } from "@/hooks/use-chat";

export default function Home() {
  const [initialized, setInitialized] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isAudioEnabled, setIsAudioEnabled] = useState(true);
  const [faceData, setFaceData] = useState({ yaw: 0, pitch: 0, mouthOpen: 0 });

  // Prefetch/connect functionality
  const { isLoading: isHistoryLoading } = useChatHistory();

  const handleInitialize = () => {
    // Resume audio context if needed (browsers block autoplay)
    if (window.speechSynthesis) {
      window.speechSynthesis.resume();
    }
    setInitialized(true);
  };

  const toggleAudio = () => {
    if (isAudioEnabled) {
      window.speechSynthesis.cancel();
    }
    setIsAudioEnabled(!isAudioEnabled);
  };

  return (
    <div className="relative w-full h-screen overflow-hidden bg-[#050510]">
      {/* 1. Background Layer */}
      <AvatarScene isProcessing={isProcessing} faceData={faceData} />

      {/* 2. UI Overlay Layer */}
      {initialized && (
        <main className="absolute inset-0 z-10 pointer-events-none">
          {/* Camera Feed */}
          <CameraPreview onFaceUpdate={setFaceData} />

          {/* Header */}
          <header className="absolute top-0 left-0 right-0 p-6 flex justify-between items-start pointer-events-auto">
            <div>
              <h1 className="text-2xl font-bold font-['Orbitron'] text-cyan-400 tracking-wider">
                AURA
              </h1>
              <div className="flex items-center gap-2 mt-1">
                <span className="w-2 h-2 bg-green-500 rounded-full shadow-[0_0_8px_#22c55e]" />
                <span className="text-[10px] text-green-500/80 font-mono tracking-widest uppercase">
                  Connected
                </span>
              </div>
            </div>

            <div className="flex flex-col items-end gap-1">
              <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 backdrop-blur-sm">
                {isProcessing ? (
                  <>
                    <Loader2 className="w-3 h-3 text-purple-400 animate-spin" />
                    <span className="text-xs text-purple-400 font-mono tracking-wider">PROCESSING</span>
                  </>
                ) : (
                  <>
                    <span className="w-2 h-2 bg-cyan-500 rounded-full animate-pulse" />
                    <span className="text-xs text-cyan-400 font-mono tracking-wider">IDLE</span>
                  </>
                )}
              </div>
            </div>
          </header>

          {/* Chat Interface */}
          <ChatInterface 
            onProcessingChange={setIsProcessing} 
            isAudioEnabled={isAudioEnabled}
            onAudioToggle={toggleAudio}
          />
        </main>
      )}

      {/* 3. System Initialization Overlay */}
      {!initialized && <SystemOverlay onInitialize={handleInitialize} />}
      
      {/* Loading Fallback for heavy assets */}
      {initialized && isHistoryLoading && (
        <div className="absolute inset-0 z-40 flex items-center justify-center bg-black/50 backdrop-blur-sm pointer-events-none">
          <div className="text-cyan-500 font-mono animate-pulse">LOADING MEMORY BANKS...</div>
        </div>
      )}
    </div>
  );
}
