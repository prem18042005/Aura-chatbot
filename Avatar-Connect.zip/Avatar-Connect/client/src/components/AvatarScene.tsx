import { motion } from "framer-motion";

interface FaceData {
  yaw: number;
  pitch: number;
  mouthOpen: number;
}

interface AvatarSceneProps {
  isProcessing: boolean;
  faceData?: FaceData;
}

export default function AvatarScene({ isProcessing, faceData }: AvatarSceneProps) {
  // Movement multipliers for smoothness
  const headYaw = (faceData?.yaw || 0) * 0.8;
  const headPitch = (faceData?.pitch || 0) * 0.5;
  const mouthScaleY = 1 + (faceData?.mouthOpen || 0) * 0.05;

  return (
    <div className="absolute inset-0 z-0 bg-[#050510]">
      <div 
        className="absolute inset-0 flex items-center justify-center opacity-80"
        style={{
          backgroundImage: 'radial-gradient(circle at center, rgba(112, 0, 255, 0.15) 0%, transparent 70%)'
        }}
      >
        <motion.div
          animate={{
            x: headYaw * 2,
            y: headPitch * 2,
            rotateY: headYaw,
            rotateX: -headPitch,
            scale: isProcessing ? [1, 1.02, 1] : 1,
          }}
          transition={{
            type: "spring",
            stiffness: 100,
            damping: 20,
            mass: 1
          }}
          className="relative w-full h-full max-w-4xl max-h-[80vh] flex items-center justify-center perspective-[1000px]"
        >
          {/* Main Avatar Image */}
          <div className="relative">
            <img 
              src="/images/avatar.png" 
              alt="AURA Avatar" 
              className="w-full h-full object-contain drop-shadow-[0_0_30px_rgba(0,242,255,0.3)]"
            />
            
            {/* Lip Sync Effect - Glowing Overlay that scales with mouth opening */}
            <motion.div
              animate={{
                scaleY: mouthScaleY,
                opacity: faceData?.mouthOpen ? 0.8 : 0,
              }}
              className="absolute top-[48%] left-1/2 -translate-x-1/2 w-16 h-4 bg-cyan-400/30 blur-md rounded-[50%] pointer-events-none"
            />
          </div>

          {/* Cybernetic overlays */}
          <div className="absolute inset-0 pointer-events-none">
            <div className="absolute top-1/4 left-1/4 w-32 h-32 border-l border-t border-cyan-500/20 rounded-tl-3xl" />
            <div className="absolute bottom-1/4 right-1/4 w-32 h-32 border-r border-b border-purple-500/20 rounded-br-3xl" />
          </div>
        </motion.div>
      </div>

      {/* Grid Floor Effect */}
      <div 
        className="absolute bottom-0 left-0 right-0 h-64 opacity-20 pointer-events-none"
        style={{
          backgroundImage: `linear-gradient(to top, #7000ff33 1px, transparent 1px), linear-gradient(to right, #00f2ff33 1px, transparent 1px)`,
          backgroundSize: '40px 40px',
          perspective: '500px',
          transform: 'rotateX(60deg) scale(2)',
          transformOrigin: 'bottom'
        }}
      />
    </div>
  );
}
