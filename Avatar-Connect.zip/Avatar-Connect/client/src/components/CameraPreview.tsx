import { useRef, useEffect, useState } from "react";
import { FaceMesh } from "@mediapipe/face_mesh";
import * as cam from "@mediapipe/camera_utils";

interface FaceData {
  yaw: number;
  pitch: number;
  mouthOpen: number;
}

interface CameraPreviewProps {
  onFaceUpdate?: (data: FaceData) => void;
}

export default function CameraPreview({ onFaceUpdate }: CameraPreviewProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isFaceDetected, setIsFaceDetected] = useState(false);

  useEffect(() => {
    const faceMesh = new FaceMesh({
      locateFile: (file) => `https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh/${file}`,
    });

    faceMesh.setOptions({
      maxNumFaces: 1,
      refineLandmarks: true,
      minDetectionConfidence: 0.5,
      minTrackingConfidence: 0.5,
    });

    faceMesh.onResults((results) => {
      if (results.multiFaceLandmarks && results.multiFaceLandmarks.length > 0) {
        setIsFaceDetected(true);
        const landmarks = results.multiFaceLandmarks[0];

        // Basic Head Tracking (Yaw/Pitch)
        // Midpoint of eyes vs nose tip
        const nose = landmarks[1];
        const leftEye = landmarks[33];
        const rightEye = landmarks[263];
        
        const yaw = (nose.x - (leftEye.x + rightEye.x) / 2) * 100;
        const pitch = (nose.y - (leftEye.y + rightEye.y) / 2) * 100;

        // Lip Sync (Mouth Openness)
        // Top lip (13) vs Bottom lip (14)
        const mouthTop = landmarks[13];
        const mouthBottom = landmarks[14];
        const mouthOpen = Math.max(0, (mouthBottom.y - mouthTop.y) * 500);

        onFaceUpdate?.({ yaw, pitch, mouthOpen });
      } else {
        setIsFaceDetected(false);
      }
    });

    let camera: cam.Camera | null = null;
    if (videoRef.current) {
      camera = new cam.Camera(videoRef.current, {
        onFrame: async () => {
          if (videoRef.current) {
            await faceMesh.send({ image: videoRef.current });
          }
        },
        width: 640,
        height: 480,
      });
      camera.start();
    }

    return () => {
      camera?.stop();
      faceMesh.close();
    };
  }, [onFaceUpdate]);

  return (
    <div className="absolute top-6 right-6 z-20 w-48 aspect-video rounded-lg overflow-hidden border border-cyan-500/30 bg-black/40 backdrop-blur-sm shadow-[0_0_15px_rgba(0,242,255,0.2)] pointer-events-auto">
      <video
        ref={videoRef}
        autoPlay
        playsInline
        muted
        className="w-full h-full object-cover scale-x-[-1]"
      />
      <div className="absolute top-2 left-2 flex items-center gap-1.5">
        <div className={`w-1.5 h-1.5 rounded-full animate-pulse ${isFaceDetected ? 'bg-green-500' : 'bg-red-500'}`} />
        <span className="text-[8px] text-white/70 font-mono tracking-tighter uppercase">
          {isFaceDetected ? 'Tracking' : 'Searching Face'}
        </span>
      </div>
    </div>
  );
}
