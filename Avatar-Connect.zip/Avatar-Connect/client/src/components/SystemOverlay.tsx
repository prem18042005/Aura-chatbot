import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Power } from "lucide-react";

interface SystemOverlayProps {
  onInitialize: () => void;
}

export default function SystemOverlay({ onInitialize }: SystemOverlayProps) {
  const [isExiting, setIsExiting] = useState(false);

  const handleInit = () => {
    setIsExiting(true);
    // Slight delay to allow animation to start
    setTimeout(onInitialize, 800); 
  };

  return (
    <AnimatePresence>
      {!isExiting && (
        <motion.div
          className="fixed inset-0 z-50 flex items-center justify-center bg-[#050510] text-white"
          exit={{ opacity: 0, scale: 1.1, filter: "blur(20px)" }}
          transition={{ duration: 0.8, ease: "easeInOut" }}
        >
          <div className="relative flex flex-col items-center">
            {/* Spinning decorative rings */}
            <div className="absolute inset-0 -z-10 flex items-center justify-center">
              <div className="w-[300px] h-[300px] border border-cyan-500/20 rounded-full animate-spin-slow" style={{ animationDuration: '10s' }} />
              <div className="absolute w-[250px] h-[250px] border border-purple-500/20 rounded-full animate-reverse-spin" style={{ animationDuration: '7s' }} />
            </div>

            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-6xl md:text-8xl font-black font-['Orbitron'] tracking-tighter mb-2 text-transparent bg-clip-text bg-gradient-to-b from-cyan-300 to-cyan-600 drop-shadow-[0_0_15px_rgba(0,242,255,0.5)]"
            >
              AURA
            </motion.h1>
            
            <motion.p 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3 }}
              className="text-cyan-500/60 font-mono tracking-[0.5em] text-sm mb-12"
            >
              ADVANCED USER RESPONSE AGENT
            </motion.p>

            <motion.button
              onClick={handleInit}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="group relative px-8 py-4 bg-transparent border border-cyan-500/30 rounded-full overflow-hidden"
            >
              <div className="absolute inset-0 bg-cyan-500/10 group-hover:bg-cyan-500/20 transition-colors duration-300" />
              <div className="relative flex items-center gap-3 text-cyan-400 font-['Orbitron'] font-bold tracking-widest uppercase">
                <Power size={20} className="group-hover:shadow-[0_0_10px_cyan]" />
                Initialize System
              </div>
            </motion.button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
