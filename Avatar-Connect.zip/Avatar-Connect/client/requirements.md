## Packages
@react-three/fiber | For 3D avatar visualization
@react-three/drei | Helpers for Three.js
three | Core 3D library
framer-motion | Smooth UI animations
regenerator-runtime | Required for speech recognition
react-speech-recognition | Easy voice input handling

## Notes
Using Web Speech API for Text-to-Speech (window.speechSynthesis)
Using React Speech Recognition for Speech-to-Text
Backend API expects JSON content at POST /api/chat
Three.js scene renders on z-index 0, UI on z-index 5
