import { useState, useEffect, useRef } from "react";
import { Mic, MicOff, Send, Trash2, Power, Volume2, VolumeX } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import 'regenerator-runtime/runtime';
import SpeechRecognition, { useSpeechRecognition } from 'react-speech-recognition';
import { useSendMessage, useClearChat, useChatHistory } from "@/hooks/use-chat";

interface ChatInterfaceProps {
  onProcessingChange: (isProcessing: boolean) => void;
  isAudioEnabled: boolean;
  onAudioToggle: () => void;
}

export default function ChatInterface({ 
  onProcessingChange, 
  isAudioEnabled, 
  onAudioToggle 
}: ChatInterfaceProps) {
  const [inputValue, setInputValue] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  const { data: messages, isLoading } = useChatHistory();
  const sendMessageMutation = useSendMessage();
  const clearChatMutation = useClearChat();

  const {
    transcript,
    listening,
    resetTranscript,
    browserSupportsSpeechRecognition
  } = useSpeechRecognition();

  // Scroll to bottom on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Handle voice input
  useEffect(() => {
    if (transcript) {
      setInputValue(transcript);
    }
  }, [transcript]);

  // Update processing state for avatar
  useEffect(() => {
    onProcessingChange(sendMessageMutation.isPending);
  }, [sendMessageMutation.isPending, onProcessingChange]);

  // Text-to-Speech Response
  useEffect(() => {
    // Check if the last message is from assistant and we just received it
    const lastMessage = messages?.[messages.length - 1];
    if (
      isAudioEnabled && 
      lastMessage?.role === 'assistant' && 
      !isLoading &&
      !sendMessageMutation.isPending
    ) {
      // Simple debounce/check to avoid re-reading old messages on refresh
      // In a real app, we'd track "read" state or use a timestamp comparison
      const now = new Date();
      const msgTime = new Date(lastMessage.createdAt || now);
      if (now.getTime() - msgTime.getTime() < 5000) { // Only read if less than 5s old
        speak(lastMessage.content);
      }
    }
  }, [messages, isAudioEnabled, isLoading, sendMessageMutation.isPending]);

  const speak = (text: string) => {
    if (!window.speechSynthesis) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    // Try to find a good sci-fi voice (often Google US English or Microsoft Zira)
    const voices = window.speechSynthesis.getVoices();
    const preferredVoice = voices.find(v => v.name.includes("Google US English") || v.name.includes("Zira"));
    if (preferredVoice) utterance.voice = preferredVoice;
    
    utterance.pitch = 1.0;
    utterance.rate = 1.0;
    window.speechSynthesis.speak(utterance);
  };

  const handleSend = async () => {
    if (!inputValue.trim()) return;
    
    const content = inputValue;
    setInputValue("");
    resetTranscript();
    
    await sendMessageMutation.mutateAsync(content);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const toggleListening = () => {
    if (listening) {
      SpeechRecognition.stopListening();
    } else {
      SpeechRecognition.startListening({ continuous: true });
    }
  };

  if (!browserSupportsSpeechRecognition) {
    // Fallback or warning could go here
    console.warn("Browser does not support speech recognition.");
  }

  return (
    <div className="absolute inset-x-0 bottom-0 z-10 flex flex-col items-center justify-end p-4 pb-8 md:pb-12 h-[60vh] pointer-events-none">
      
      {/* Messages Area */}
      <div className="w-full max-w-3xl flex-1 overflow-y-auto mb-6 px-4 custom-scrollbar pointer-events-auto">
        <AnimatePresence initial={false}>
          {messages?.map((msg) => (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.3 }}
              className={`flex mb-4 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`
                  max-w-[85%] md:max-w-[70%] p-4 rounded-2xl backdrop-blur-md border
                  ${msg.role === 'user' 
                    ? 'bg-white/5 border-white/10 text-white rounded-tr-sm' 
                    : 'bg-[#00f2ff]/10 border-[#00f2ff]/30 text-[#00f2ff] rounded-tl-sm shadow-[0_0_15px_rgba(0,242,255,0.1)]'
                  }
                `}
              >
                <p className="text-sm md:text-base leading-relaxed font-medium">
                  {msg.content}
                </p>
                <span className="text-[10px] opacity-50 mt-1 block uppercase tracking-wider font-mono">
                  {msg.role === 'user' ? 'CMD: USER' : 'SYS: AURA'}
                </span>
              </div>
            </motion.div>
          ))}
          
          {sendMessageMutation.isPending && (
            <motion.div 
              initial={{ opacity: 0 }} 
              animate={{ opacity: 1 }}
              className="flex justify-start mb-4"
            >
              <div className="bg-[#7000ff]/10 border border-[#7000ff]/30 text-[#7000ff] p-4 rounded-2xl rounded-tl-sm flex items-center gap-2">
                <span className="w-2 h-2 bg-[#7000ff] rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                <span className="w-2 h-2 bg-[#7000ff] rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                <span className="w-2 h-2 bg-[#7000ff] rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
            </motion.div>
          )}
        </AnimatePresence>
        <div ref={messagesEndRef} />
      </div>

      {/* Input Control Panel */}
      <div className="w-full max-w-3xl glass-panel rounded-full p-2 pl-6 pr-2 flex items-center gap-4 pointer-events-auto border-glow-cyan shadow-2xl">
        {/* Status / Clear */}
        <div className="flex items-center gap-2 mr-2 border-r border-white/10 pr-4">
           <button
            onClick={onAudioToggle}
            className={`
              p-2 rounded-full transition-all duration-200
              ${isAudioEnabled 
                ? 'text-cyan-400 hover:text-cyan-300 hover:bg-cyan-900/20' 
                : 'text-gray-500 hover:text-gray-400'
              }
            `}
            title={isAudioEnabled ? "Mute TTS" : "Enable TTS"}
          >
            {isAudioEnabled ? <Volume2 size={18} /> : <VolumeX size={18} />}
          </button>
          
          <button 
            onClick={() => clearChatMutation.mutate()}
            disabled={clearChatMutation.isPending}
            className="text-gray-500 hover:text-red-400 transition-colors p-2"
            title="Clear Memory"
          >
            <Trash2 size={18} />
          </button>
        </div>

        {/* Text Input */}
        <input
          type="text"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder={listening ? "Listening..." : "Enter command..."}
          className="flex-1 bg-transparent border-none outline-none text-white placeholder-gray-500 font-mono text-base md:text-lg"
          disabled={sendMessageMutation.isPending}
        />

        {/* Action Buttons */}
        <div className="flex items-center gap-2">
          {browserSupportsSpeechRecognition && (
            <button
              onClick={toggleListening}
              className={`
                p-3 rounded-full transition-all duration-300
                ${listening 
                  ? 'bg-red-500/20 text-red-500 shadow-[0_0_15px_rgba(239,68,68,0.5)] animate-pulse' 
                  : 'hover:bg-white/5 text-gray-400 hover:text-cyan-400'
                }
              `}
            >
              {listening ? <MicOff size={20} /> : <Mic size={20} />}
            </button>
          )}

          <button
            onClick={handleSend}
            disabled={!inputValue.trim() || sendMessageMutation.isPending}
            className={`
              p-3 rounded-full bg-cyan-500 text-black font-bold transition-all duration-300
              hover:bg-cyan-400 hover:scale-105 active:scale-95 disabled:opacity-50 disabled:hover:scale-100
              shadow-[0_0_20px_rgba(0,242,255,0.3)] hover:shadow-[0_0_30px_rgba(0,242,255,0.5)]
            `}
          >
            <Send size={20} className={sendMessageMutation.isPending ? "opacity-0" : "opacity-100"} />
            {sendMessageMutation.isPending && (
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
              </div>
            )}
          </button>
        </div>
      </div>
      
      {/* Decorative Footer */}
      <div className="mt-4 flex items-center justify-center gap-8 text-[10px] text-cyan-500/40 font-mono tracking-[0.2em] uppercase">
        <span>System: Online</span>
        <span>Ver: 2.5.0</span>
        <span>AURA AI</span>
      </div>
    </div>
  );
}
