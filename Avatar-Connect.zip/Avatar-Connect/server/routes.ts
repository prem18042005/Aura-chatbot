import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import OpenAI from "openai";

// Initialize OpenAI with Replit AI Integration credentials
const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // Seed database
  const existingMessages = await storage.getMessages();
  if (existingMessages.length === 0) {
    await storage.createMessage("assistant", "System initialized. I am Aura, your real-time AI companion. How can I assist you with your innovation project today?");
  }

  app.get(api.chat.history.path, async (req, res) => {
    const messages = await storage.getMessages();
    res.json(messages);
  });

  app.post(api.chat.send.path, async (req, res) => {
    try {
      const { content } = api.chat.send.input.parse(req.body);

      // 1. Save user message
      await storage.createMessage("user", content);

      // 2. Get history for context
      const history = await storage.getMessages();
      const messages = history.map(msg => ({
        role: msg.role as "user" | "assistant" | "system",
        content: msg.content
      }));

      // 3. Call OpenAI
      const response = await openai.chat.completions.create({
        model: "gpt-5", 
        messages: [
          { 
            role: "system", 
            content: "You are AURA, a futuristic AI companion. You are helpful, concise, and speak in a slightly robotic but warm tone. You exist in a cyberpunk interface." 
          },
          ...messages
        ],
        max_completion_tokens: 500,
      });

      const aiContent = response.choices[0].message.content || "I am processing...";

      // 4. Save AI message
      const aiMessage = await storage.createMessage("assistant", aiContent);

      res.json(aiMessage);
    } catch (err) {
      console.error(err);
      if (err instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid input", field: err.errors[0].path.join(".") });
      } else {
        res.status(500).json({ message: "Internal server error" });
      }
    }
  });

  app.delete(api.chat.clear.path, async (req, res) => {
    await storage.clearMessages();
    res.status(204).send();
  });

  return httpServer;
}
